

module.exports ={
     accordionSizeforDuplicateSearch : 2,
     accordionSizeforTotalCount : 4,
     mylink : 'http://173.165.99.66/pathtrak/direct',
     headermypic : 'assets/images/viavi-purple-logo.png'
}