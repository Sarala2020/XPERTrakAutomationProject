const { element, browser } = require("protractor");

function HeaderVerificationObject()
{
    var elemenuButton = element(by.css("button.menu-button.menu-toggle"));
    var elemenuText = element(by.css("span[class='menu-text-ellipse menu-text darkMenu']"));    
    var eleTradeMarkContent = element(by.css("div.descriptor:nth-child(3) > p.header-trademark.product"))
    var elesearchBox = element(by.xpath('//*[@id="searchBox"]'));
    var elemypic = element(by.css("img[src*='images/viavi-purple-logo.png']"));
    var eleThemeIcon = element(by.xpath('//*[@id="menu-toggle"]/i'));
    var eleThemeVerify = element(by.className('dark-theme'));
    
    /*this.OpenRegionalSearchPageVerification = function()
    {
        elemenuButton.click().then(function()
        {
            elemenuText.getText().then(function(text)
                     {
                        //expect(text).toBe('Regional Search');
                        browser.sleep(3000);
                        expect(elesearchBox.isDisplayed()).toBe(true);
                     })
        })
    }*/

    this.viaviImageVerification = function()
    {
        // To verify Viavi logo is displayed or not  
      browser.isElementPresent(elemypic).then(function (result) {
       if(result){
                console.log(result);
                expect(elemypic.getAttribute('src')).toContain(globalData.headermypic);
                 }
               });
    }

    this.xperttrakContentVerification = function()
    {
        eleTradeMarkContent.getText().then(function(value)
        {
            expect(value).toBe('XPERTrak™ Enterprise');
        })
    }

    this.toggleHeaderVerification = function()
    {
        elemenuButton.click().then(function()
        {
            browser.sleep(3000);
            expect(elemenuText.isDisplayed()).toBe(true);    
                
        })
        elemenuButton.click().then(function()
        {
            browser.sleep(3000);
            //expect(elemenuText.isPresent()).toBe(false);                
        })
    }
    this.xpertrackThemeVerification = function()
    {
        eleThemeIcon.click().then(function()
        {
            browser.sleep(3000);
            expect(eleThemeVerify.isPresent()).toBe(true);   
        })        

        eleThemeIcon.click().then(function()
        {
            browser.sleep(3000);
            expect(eleThemeVerify.isPresent()).toBe(false);   
        })      
    }
}

module.exports = new HeaderVerificationObject();