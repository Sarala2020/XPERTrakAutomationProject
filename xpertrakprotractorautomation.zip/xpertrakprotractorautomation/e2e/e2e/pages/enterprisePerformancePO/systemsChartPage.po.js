const { element, browser } = require("protractor");
var dnd = require('html-dnd').code;

function EnterpriseSystemChartObject()
{
    
var eleSystemMonthlyButton = element(by.xpath('//*[@id="fstdiv2 "]/div/div[4]/button[2]'));
var eleSystemDailyButton = element(by.xpath('//*[@id="fstdiv2 "]/div/div[4]/button[1]'));
var eleSystemMacTrakbutton = element(by.xpath('//*[@id="fstdiv2 "]/div/div[4]/select[1]'));
var eleSystemMacTrackbuttonOptions = element.all(by.tagName('option'));
//To verify checkboxes graph validation 
var eleSystemHighchartItem = element(by.xpath("//as-split[1]/as-split-area[2]/app-system-chart[1]/div[1]/div[2]/div[1]/div[2]/highcharts-chart[1]/div[1]/*[local-name()='svg'][1]/*[name()='g'][5]/*[name()='g'][1]/*[name()='rect'][1]"));
//To verify Zoom
var eleSystemHighchartforCheck1Item = element(by.xpath("//as-split[1]/as-split-area[2]/app-system-chart[1]/div[1]/div[2]/div[1]/div[2]/highcharts-chart[1]/div[1]/*[local-name()='svg'][1]/*[name()='g'][5]/*[name()='g'][3]/*[name()='rect'][1]"));
//For Indy
var eleSystemHighchartsAllforCheckbox1 = element.all(by.xpath("//as-split[1]/as-split-area[2]/app-system-chart[1]/div[1]/div[2]/div[1]/div[2]/highcharts-chart[1]/div[1]/*[local-name()='svg'][1]/*[name()='g'][5]/*[name()='g'][3]/*[name()='rect']"));
//For Spy
var eleSystemHighchartsAllforCheckbox2 = element.all(by.xpath("//as-split[1]/as-split-area[2]/app-system-chart[1]/div[1]/div[2]/div[1]/div[2]/highcharts-chart[1]/div[1]/*[local-name()='svg'][1]/*[name()='g'][5]/*[name()='g'][1]/*[name()='rect']"));

var eleSystemShowAllCheckbox = element(by.xpath('//*[@id="selallsys"]'));
var eleSystemHighChartdestination = element(by.xpath("//as-split[1]/as-split-area[2]/app-system-chart[1]/div[1]/div[2]/div[1]/div[2]/highcharts-chart[1]/div[1]/*[local-name()='svg'][1]/*[name()='g'][5]/*[name()='g'][1]/*[name()='rect'][1]"));
//var eleResetZoombutton = element(by.xpath("//*[local-name() = 'g' and @class = 'highcharts-button highcharts-reset-zoom          highcharts-button-normal']"));
var eleSystemMenuButton = element(by.xpath("//as-split-area[@id='spltr2']//a[1]//i[1]"));
var eleCheckItemDropdown = element(by.xpath('//*[@id="fstdiv2 "]/div/div[3]/select'));
//var eleSystemResetZoombutton = element(by.xpath("//div[@id='highcharts-4ej8d1p-2']//*[local-name()='svg']//*[name()='g'][7]/*[name()='rect'][1]"));

var toolTipCount;    

this.get = function(url){

        browser.get(url);
    };

this.sysMonthlyButtonValidation = function()
{
   // monthlyButton.click();
   expect(eleSystemMonthlyButton.isEnabled()).toBe(false);   
}
//To retrieve the graph values from Spy chart(CheckBox1)

 this.sysVerifySystemHighChartItemdataforCheckbox1 = function(buttonValue,mactrakdropdownvalue,checkItem1,checkItem2,Monthly_Check1MacTrakGraphCount,Monthly_Check1SpectralGraphCount,Daily_Check1MacTrakGraphCount,Daily_Check1SpectralGraphCount)
 {    
        // To get the rect values related to graphs count for dialy
        //element.all(by.xpath("//split-area[1]/regionchart[1]/div[1]/div[2]/div[1]/div[2]/chart[1]/div[1]/*[local-name()='svg'][1]/*[name()='g'][5]/*[name()='g'][1]/*[name()='rect']")).count().then(function(size)
        eleSystemHighchartsAllforCheckbox1.count().then(function(size)
        {
            var TotalSystemChartsResultsCheck1 = size;
            //console.log("IndyChartsCount:" +TotalSystemIndyChartsResults);  
            
            for(var i = 1; i<=TotalSystemChartsResultsCheck1; i++)
            {
                browser.sleep(10000);     
                var mouseEle = element(by.xpath("//as-split[1]/as-split-area[2]/app-system-chart[1]/div[1]/div[2]/div[1]/div[2]/highcharts-chart[1]/div[1]/*[local-name()='svg'][1]/*[name()='g'][5]/*[name()='g'][3]/*[name()='rect']["+i+"]"));                                                 
                
                browser.actions().mouseMove(mouseEle).perform();
                mouseEle.click().then(function()
                    {
                    browser.sleep(10000);  
                    element.all(by.css("g.highcharts-tooltip tspan")).count().then(function(size)
                       {
                        toolTipCount = size;
                        console.log("tooltipcountforIndy" +toolTipCount);
                       })
               
                        element.all(by.css("g.highcharts-tooltip")).each(function(item)			
                           {                        
                           for(var Counter = 1; Counter<=toolTipCount; Counter++)
                               {
                                   item.element(by.css("tspan:nth-of-type("+Counter+")")).getText().then(function(value)
                                       {
                                          // console.log("TooltipText="+ value);
                                          switch(value){
                                            case "MACTrak™":
                                                if(mactrakdropdownvalue== 'mactrak'|| mactrakdropdownvalue== 'both') 
                                               { expect(value).toMatch("MACTrak™");}
                                                break;
                                             case "Spectral":
                                                if(mactrakdropdownvalue== 'spectral'|| mactrakdropdownvalue== 'both')  
                                               { expect(value).toMatch("Spectral");}
                                                 break;        
            
                                            case checkItem1:
                                                expect(value).toMatch(checkItem1);
                                                break;                              
            
                                            case checkItem2:
                                                expect(value).toMatch(checkItem2);
                                                break;                               
            
                                            case "Percent Failed:":
                                                expect(value).toMatch("Percent Failed:");
                                                break;                               
            
                                            case "Performance Severity:":
                                                expect(value).toMatch("Performance Severity:");
                                                break;                               
                                                
                                            case "Date:":
                                                expect(value).toMatch("Date:");
                                                break;     
                                        }
                                       })
                                }        
                            })                    
                    })
                }
                if(buttonValue == "monthly" && mactrakdropdownvalue == "spectral")
                    {
                        expect(TotalSystemChartsResultsCheck1).toBe(Monthly_Check1SpectralGraphCount);
                    }
                else if(buttonValue == "monthly" && mactrakdropdownvalue== "mactrak") 
                    {
                        expect(TotalSystemChartsResultsCheck1).toBe(Monthly_Check1MacTrakGraphCount);
                    }        
                    
                else if(buttonValue == "daily" && mactrakdropdownvalue == "spectral")
                    {
                       expect(TotalSystemChartsResultsCheck1).toBe(Daily_Check1SpectralGraphCount);
                    }
                else if(buttonValue == "daily" && mactrakdropdownvalue== "mactrak") 
                    {
                        expect(TotalSystemChartsResultsCheck1).toBe(Daily_Check1MacTrakGraphCount);
                    }                
            })       
    }
    //To retrieve the graph values from Spy chart(CheckBox2)
    this.sysVerifySystemHighChartItemdataforCheckbox2 = function(buttonValue,mactrakdropdownvalue,checkItem1,checkItem2,Monthly_Check2MacTrakGraphCount,Monthly_Check2SpectralGraphCount,Daily_Check2MacTrakGraphCount,Daily_Check2SpectralGraphCount)
    {    
        browser.sleep(10000);  

           // To get the rect values related to graphs count for dialy
           //element.all(by.xpath("//split-area[1]/regionchart[1]/div[1]/div[2]/div[1]/div[2]/chart[1]/div[1]/*[local-name()='svg'][1]/*[name()='g'][5]/*[name()='g'][1]/*[name()='rect']")).count().then(function(size)
           eleSystemHighchartsAllforCheckbox2.count().then(function(size)
           {
               var TotalSystemChartsResultsCheck2 = size;
               console.log("SpyChartsCount:" +TotalSystemChartsResultsCheck2);
               console.log("MonthlyMactrakCount:" +Monthly_Check2MacTrakGraphCount);
               console.log("MonthlySpectralCount:" +Monthly_Check2SpectralGraphCount);
               console.log("DailyMactrakCount:" +Daily_Check2MacTrakGraphCount);
               console.log("DailySpectralCount:" +Daily_Check2SpectralGraphCount); 

               
               for(var i = 1; i<=TotalSystemChartsResultsCheck2; i++)
                   {
                    var mouseEle = element(by.xpath("//as-split[1]/as-split-area[2]/app-system-chart[1]/div[1]/div[2]/div[1]/div[2]/highcharts-chart[1]/div[1]/*[local-name()='svg'][1]/*[name()='g'][5]/*[name()='g'][1]/*[name()='rect']["+i+"]"));
                    browser.actions().mouseMove(mouseEle).perform();
                    mouseEle.click().then(function()
                       {
                       browser.sleep(10000);  
                       element.all(by.css("g.highcharts-tooltip tspan")).count().then(function(size)
                          {
                           toolTipCount = size;
                           console.log("tooltipcountforSpy:" + toolTipCount);
                          }) 
                  
                            element.all(by.css("g.highcharts-tooltip")).each(function(item)			
                              {                        
                              for(var Counter = 1; Counter<=toolTipCount; Counter++)
                                  {
                                      item.element(by.css("tspan:nth-of-type("+Counter+")")).getText().then(function(value)
                                          {
                                             // console.log("TooltipText="+ value);
                                             switch(value){
                                               case "MACTrak™":
                                                   if(mactrakdropdownvalue== 'mactrak'|| mactrakdropdownvalue== 'both') 
                                                  { expect(value).toMatch("MACTrak™");}
                                                   break;
                                                case "Spectral":
                                                   if(mactrakdropdownvalue== 'spectral'|| mactrakdropdownvalue== 'both')  
                                                  { expect(value).toMatch("Spectral");}
                                                    break;        
               
                                               case checkItem1:
                                                   expect(value).toMatch(checkItem1);
                                                   break;                              
               
                                               case checkItem2:
                                                   expect(value).toMatch(checkItem2);
                                                   break;                               
               
                                               case "Percent Failed:":
                                                   expect(value).toMatch("Percent Failed:");
                                                   break;                               
               
                                               case "Performance Severity:":
                                                   expect(value).toMatch("Performance Severity:");
                                                   break;                               
                                                   
                                               case "Date:":
                                                   expect(value).toMatch("Date:");
                                                   break;     
                                           }
   
                                          })
                                   }        
                               })                    
                       })
                   }
                   if(buttonValue == "monthly" && mactrakdropdownvalue == "spectral")
                    {
                        expect(TotalSystemChartsResultsCheck2).toBe(Monthly_Check2SpectralGraphCount);
                    }
                  else if(buttonValue == "monthly" && mactrakdropdownvalue== "mactrak") 
                    {
                        expect(TotalSystemChartsResultsCheck2).toBe(Monthly_Check2MacTrakGraphCount);
                    }                   
                   if(buttonValue == "daily" && mactrakdropdownvalue == "spectral")
                    {
                        expect(TotalSystemChartsResultsCheck2).toBe(Daily_Check2SpectralGraphCount);
                    }
                  else if(buttonValue == "daily" && mactrakdropdownvalue== "mactrak") 
                    {
                        expect(TotalSystemChartsResultsCheck2).toBe(Daily_Check2MacTrakGraphCount);
                    }             
               })        
       }
this.sysVerifyCheck1SystemHighChartItemdataforBoth = function(buttonValue,mactrakdropdownvalue,Monthly_Check1BothGraphCount,Daily_Check1BothGraphCount)
{
    eleSystemHighchartsAllforCheckbox1.count().then(function(size)
        {
            var TotalSystemChartsResultsCheck1 = size;
            //console.log("SpyChartsCount:" +TotalSystemSpyChartsResults);
            if(buttonValue == "monthly" && mactrakdropdownvalue== "both")
                {
                    expect(TotalSystemChartsResultsCheck1).toBe(Monthly_Check1BothGraphCount);
                }
            if(buttonValue == "daily" && mactrakdropdownvalue== "both")
                {
                    expect(TotalSystemChartsResultsCheck1).toBe(Daily_Check1BothGraphCount);
                }            
        })  
}
this.sysVerifyCheck2SystemHighChartItemdataforBoth = function(buttonValue,mactrakdropdownvalue,Monthly_Check2BothGraphCount,Daily_Check2BothGraphCount)
{
    eleSystemHighchartsAllforCheckbox2.count().then(function(size)
        {
            var TotalSystemChartsResultsCheck2 = size;
            console.log("SpyChartsCountforBoth:" +TotalSystemChartsResultsCheck2);
            console.log("MonthlyBothResult:" +Monthly_Check2BothGraphCount);
            console.log("DAilyBothResult:" +Daily_Check2BothGraphCount);

            if(buttonValue == "monthly" && mactrakdropdownvalue== "both")
                {
                    expect(TotalSystemChartsResultsCheck2).toBe(Monthly_Check2BothGraphCount);
                }
            if(buttonValue == "daily" && mactrakdropdownvalue== "both")
                {
                    expect(TotalSystemChartsResultsCheck2).toBe(Daily_Check2BothGraphCount);
                }            
        })  
}

this.selectCheckItemDropdown = function(checkItem1)
 {    
    eleCheckItemDropdown.click();
    eleSystemMacTrackbuttonOptions.each(function(item)
    {
        item.getAttribute("value").then(function(values)
        {
            if(values == checkItem1)
            {
                item.click();
                browser.sleep(5000);
                expect(eleSystemHighchartItem.isDisplayed()).toBe(true);  
                return true;            
            }            
        })
     })
    expect(eleSystemHighchartItem.isDisplayed()).toBe(true);
 }

this.verifySysMactrakDropdown = function(name)
 {  
    var name;
    eleSystemMacTrakbutton.click();
    eleSystemMacTrackbuttonOptions.each(function(item)
    {
        item.getAttribute("value").then(function(values)
        {
            if(values == name)
            {
                item.click();
                browser.sleep(5000);  
                return true;            
            }                      
            //mactrak , spectral,  both
        })
     })
    expect(eleSystemHighchartItem.isDisplayed()).toBe(true);
 }
 

 this.clickSystemDailyButton = function()
{
    eleSystemDailyButton.click(); 
  // eleregionHighchart.isPresent().toBe(true);   
}

this.uncheckSystemCheck1 = function(chkShowAll,checkItem1,checkItem2)
    {   //Indy,selallsys,Spy
        //Uncheck one of the regions from the Regions panel
        browser.refresh();
        browser.sleep(10000);
        element(by.id(checkItem1)).click().then(function()
            {
                expect(element(by.id(checkItem2)).isSelected()).toBe(true);
                expect(element(by.id(chkShowAll)).isSelected()).toBe(false);
                expect(eleSystemHighchartItem.isDisplayed()).toBe(true);
            })
    }
this.verifygraphdataDisplayedforCheck1 = function(checkItem1)
    {        
        browser.sleep(10000); 
        browser.actions().mouseMove(eleSystemHighchartItem).perform();
        eleSystemHighchartItem.click().then(function()
            {
            browser.sleep(10000);
            element.all(by.css("g.highcharts-tooltip tspan")).count().then(function(size)
                {
                    toolTipCount = size;
                    //console.log(toolTipCount);
                })

                element.all(by.css("g.highcharts-tooltip")).each(function(item)			
                {                        
                    for(var Counter = 1; Counter<=toolTipCount; Counter++)
                        {
                            item.element(by.css("tspan:nth-of-type("+Counter+")")).getText().then(function(value)
                                {
                                    if(value==checkItem1)
                                    {
                                        expect(value).toMatch(checkItem1);
                                        //console.log(value);                                    
                                    }
                                })
                        }
                })
            })    
    }
    this.uncheckSystemCheck2 = function(chkShowAll,checkItem1,checkItem2)
    {
        browser.refresh();
        browser.sleep(10000);
        //Uncheck one of the regions from the Regions panel
        element(by.id(checkItem2)).click().then(function()
            {              
                browser.sleep(3000);
                expect(element(by.id(checkItem1)).isSelected()).toBe(true);
                expect(element(by.id(chkShowAll)).isSelected()).toBe(false);
                expect(eleSystemHighchartItem.isDisplayed()).toBe(true);
            })
    }
    this.verifygraphdataDisplayedforCheck2 = function(checkItem2)
    {   
        browser.sleep(10000); 
        browser.actions().mouseMove(eleSystemHighchartItem).perform();
        eleSystemHighchartItem.click().then(function()
            {
            browser.sleep(10000);
            element.all(by.css("g.highcharts-tooltip tspan")).count().then(function(size)
                {
                toolTipCount = size;
                //console.log(toolTipCount);
                })
                element.all(by.css("g.highcharts-tooltip")).each(function(item)			
                {                        
                    for(var Counter = 1; Counter<=toolTipCount; Counter++)
                        {
                            item.element(by.css("tspan:nth-of-type("+Counter+")")).getText().then(function(value)
                                {
                                    if(value == checkItem2)
                                    {
                                        expect(value).toMatch(checkItem2);
                                        //console.log(value);                                    
                                    }
                                })
                        }
                })
            })    
    }
this.uncheckandCheckSystemShowAll = function(chkShowAll,checkItem1,checkItem2)
    {
        browser.refresh();
        browser.sleep(10000);
        element(by.id(chkShowAll)).click().then(function()
            {
                browser.sleep(3000);
                expect(element(by.id(checkItem1)).isSelected()).toBe(false);
                expect(element(by.id(checkItem2)).isSelected()).toBe(false);
                expect(eleSystemHighchartItem.isPresent()).toBe(false);
            })
            element(by.id(chkShowAll)).click().then(function()
            {
                browser.sleep(3000);
                expect(element(by.id(checkItem1)).isSelected()).toBe(true);
                expect(element(by.id(checkItem2)).isSelected()).toBe(true);
                expect(eleSystemHighchartItem.isDisplayed()).toBe(true);
            })
    }
this.verifyUnCheckSystemShowAll = function(chkShowAll,checkItem1,checkItem2)
    {
        element(by.id(checkItem1)).click();
        element(by.id(checkItem2)).click().then(function()
        {
            browser.sleep(3000);
            expect(element(by.id(chkShowAll)).isSelected()).toBe(false);
            expect(eleSystemHighchartItem.isPresent()).toBe(false);
        })        
    }

this.verifyclickSystemMenuButton = function()
    {
        eleSystemMenuButton.click().then(function()
            {
                //expect(element(by.xpath('//*[@id="snddiv"]/div/div[1]')).isDisplayed()).toBe(false);
                browser.sleep(5000);
                expect(eleSystemShowAllCheckbox.isDisplayed()).toBe(false);                
            })
        //Click again on menu button
        eleSystemMenuButton.click().then(function()
            {
                //expect(element(by.xpath('//*[@id="snddiv"]/div/div[1]')).isDisplayed()).toBe(true);
                browser.sleep(5000);
                expect(eleSystemShowAllCheckbox.isDisplayed()).toBe(true);
            })    
    }    

this.verifyRegionZoomButton = function()
    {        
        browser.refresh();
        browser.sleep(10000);
        browser.actions().mouseMove(eleSystemHighchartforCheck1Item).perform();
        browser.actions().click(eleSystemHighchartforCheck1Item).perform();
        browser.executeScript("document.body.style.zoom='90%';");
        //browser.driver.actions().dragAndDrop(eleSystemHighchartforCheck1Item,eleSystemHighChartdestination).perform().then(function()
        browser.executeScript(dnd,eleSystemHighchartforCheck1Item,eleSystemHighChartdestination).then(function()        
            {
                browser.sleep(3000);
                expect(eleSystemHighchartforCheck1Item.isDisplayed()).toBe(true);
                //executeScript('document.getElementsByName')
                //expect(eleSystemResetZoombutton.isPresent()).toBe(true);
                //eleSystemResetZoombutton.click();
                //browser.sleep(3000);
            })        
    };
}
module.exports = new EnterpriseSystemChartObject();