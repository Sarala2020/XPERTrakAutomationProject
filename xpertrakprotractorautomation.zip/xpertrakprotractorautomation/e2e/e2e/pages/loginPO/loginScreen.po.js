const { browser } = require("protractor");

function LoginObj()
{
    var eleuserName_input = element(by.css("input[placeholder='Username']"));
    var elepassWord_input = element(by.css("input[placeholder='Password']"));
    var elesignIn = element(by.buttonText("Sign In"));
    var eleresult = element(by.id('txtSeachBox'));

    this.get = function(url)
    {
        browser.get(url);
    };

    this.enterUserName = function(userName)
    {
        eleuserName_input.sendKeys(userName);
    };

    this.enterpassWord = function(pwd)
    {
        elepassWord_input.sendKeys(pwd);
    };

    this.clickSignin = function()
    {
        elesignIn.click();
    };

    this.verifyResult = function()
    {
        browser.sleep(5000);
        expect(eleresult.isDisplayed()).toBe(true);
    };

};
module.exports = new LoginObj();