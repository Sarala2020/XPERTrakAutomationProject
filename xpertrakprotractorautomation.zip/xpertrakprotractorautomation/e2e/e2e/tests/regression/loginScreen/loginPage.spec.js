
var loginPage = require('../../../pages/loginPO/loginScreen.po');
var sync = require('../../../util/testData/constantTime');
var common = require('../commonMethods/startUpSyncMethod');
var XL = require('../../../util/testData/XLReader');
describe('Xpertrak Application Login Page:', function()
{        
    common.startUp();
    it('Login in to application with proper usename and credentials',function()
        {   
            var TEST_DATA = XL.read_from_excel('LoginTestData','./e2e/e2e/util/testData/XperTrakTestData.xlsx')
            TEST_DATA.forEach(function(data)
            {
            loginPage.get(data.URL);
            sync.wait(5000);            
            loginPage.enterUserName(data.UserName);
            loginPage.enterpassWord(data.Password);
            loginPage.clickSignin();
            sync.wait(15000);
            loginPage.verifyResult();
            })
        })
})

