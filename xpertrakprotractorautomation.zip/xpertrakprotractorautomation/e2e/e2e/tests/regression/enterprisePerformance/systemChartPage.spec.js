var loginPage = require('../../../pages/loginPO/loginScreen.po');
var EnterpriseSystemChartObject = require('../../../pages/enterprisePerformancePO/systemsChartPage.po');
var common = require('../commonMethods/startUpSyncMethod');
var sync = require('../../../util/testData/constantTime');
var XL = require('../../../util/testData/XLReader');
const { browser } = require('protractor');

describe('Xpertrak EnterpriseSearch & Performance Application ', function()
{  
      common.startUp();
       

      it('Verify the system performance page monthly',function()
        {
          var TEST_DATA = XL.read_from_excel('SystemGraph','./e2e/e2e/util/testData/XperTrakTestData.xlsx')
          TEST_DATA.forEach(function(data)
            {    
              //EnterpriseSystemChartObject.get(data.PerformanceGraphURL);
              browser.refresh();
              sync.wait(5000);
              EnterpriseSystemChartObject.selectCheckItemDropdown(data.systemsRegion);   
              EnterpriseSystemChartObject.sysMonthlyButtonValidation();
            })
        })

       it('Verify the system Graph data Monthly Mactrak',function()
        {  
          var TEST_DATA = XL.read_from_excel('SystemGraph','./e2e/e2e/util/testData/XperTrakTestData.xlsx')
          TEST_DATA.forEach(function(data)
            {          
              EnterpriseSystemChartObject.sysVerifySystemHighChartItemdataforCheckbox1("monthly","mactrak",data.checkboxItem1,data.checkboxItem2,data.Monthly_Check1MacTrakGraphCount,data.Monthly_Check1SpectralGraphCount,data.Daily_Check1MacTrakGraphCount,data.Daily_Check1SpectralGraphCount);
              EnterpriseSystemChartObject.sysVerifySystemHighChartItemdataforCheckbox2("monthly","mactrak",data.checkboxItem1,data.checkboxItem2,data.Monthly_Check2MacTrakGraphCount,data.Monthly_Check2SpectralGraphCount,data.Daily_Check2MacTrakGraphCount,data.Daily_Check2SpectralGraphCount);
            })  
        })

      it('Verify the system page for Monthly Spectral',function()
       {  
        EnterpriseSystemChartObject.verifySysMactrakDropdown("spectral");
       })
       
      
      it('Verify the System Graph data Monthly Spectral',function()
       {
          var TEST_DATA = XL.read_from_excel('SystemGraph','./e2e/e2e/util/testData/XperTrakTestData.xlsx')
          TEST_DATA.forEach(function(data)
          { 
            //EnterpriseSystemChartObject.verifySysMactrakDropdown("spectral");
            EnterpriseSystemChartObject.sysVerifySystemHighChartItemdataforCheckbox1("monthly","spectral",data.checkboxItem1,data.checkboxItem2,data.Monthly_Check1MacTrakGraphCount,data.Monthly_Check1SpectralGraphCount,data.Daily_Check1MacTrakGraphCount,data.Daily_Check1SpectralGraphCount);
            EnterpriseSystemChartObject.sysVerifySystemHighChartItemdataforCheckbox2("monthly","spectral",data.checkboxItem1,data.checkboxItem2,data.Monthly_Check2MacTrakGraphCount,data.Monthly_Check2SpectralGraphCount,data.Daily_Check2MacTrakGraphCount,data.Daily_Check2SpectralGraphCount);
          })
       })

      it('Verify the System page for Monthly both',function()
       {
          var TEST_DATA = XL.read_from_excel('SystemGraph','./e2e/e2e/util/testData/XperTrakTestData.xlsx')
          TEST_DATA.forEach(function(data)
          {  
            EnterpriseSystemChartObject.verifySysMactrakDropdown("both");
            EnterpriseSystemChartObject.sysVerifyCheck1SystemHighChartItemdataforBoth("monthly","both",data.Monthly_Check1BothGraphCount,data.Daily_Check1BothGraphCount);
            EnterpriseSystemChartObject.sysVerifyCheck2SystemHighChartItemdataforBoth("monthly","both",data.Monthly_Check2BothGraphCount,data.Daily_Check2BothGraphCount);
          })            
       })
 
      it('Verify the System graph for Daily MacTrak',function()
       {  
        EnterpriseSystemChartObject.clickSystemDailyButton();
        EnterpriseSystemChartObject.verifySysMactrakDropdown("mactrak");        
       })
      
      it('Verify the System Graph data for Daily MacTrak',function()
       {
          var TEST_DATA = XL.read_from_excel('SystemGraph','./e2e/e2e/util/testData/XperTrakTestData.xlsx')
          TEST_DATA.forEach(function(data)
          {
            EnterpriseSystemChartObject.sysVerifySystemHighChartItemdataforCheckbox1("daily","mactrak",data.checkboxItem1,data.checkboxItem2,data.Monthly_Check1MacTrakGraphCount,data.Monthly_Check1SpectralGraphCount,data.Daily_Check1MacTrakGraphCount,data.Daily_Check1SpectralGraphCount);
            EnterpriseSystemChartObject.sysVerifySystemHighChartItemdataforCheckbox2("daily","mactrak",data.checkboxItem1,data.checkboxItem2,data.Monthly_Check2MacTrakGraphCount,data.Monthly_Check2SpectralGraphCount,data.Daily_Check2MacTrakGraphCount,data.Daily_Check2SpectralGraphCount);
          })            
       })

       it('Verify the System graph for Daily Spectral',function()
       {        
        EnterpriseSystemChartObject.clickSystemDailyButton();
        EnterpriseSystemChartObject.verifySysMactrakDropdown("spectral");              
       })
      
       it('Verify the System graph data for Daily Spectral',function()
       {
          var TEST_DATA = XL.read_from_excel('SystemGraph','./e2e/e2e/util/testData/XperTrakTestData.xlsx')
          TEST_DATA.forEach(function(data)
          {
            EnterpriseSystemChartObject.sysVerifySystemHighChartItemdataforCheckbox1("daily","spectral",data.checkboxItem1,data.checkboxItem2,data.Monthly_Check1MacTrakGraphCount,data.Monthly_Check1SpectralGraphCount,data.Daily_Check1MacTrakGraphCount,data.Daily_Check1SpectralGraphCount);
            EnterpriseSystemChartObject.sysVerifySystemHighChartItemdataforCheckbox2("daily","spectral",data.checkboxItem1,data.checkboxItem2,data.Monthly_Check2MacTrakGraphCount,data.Monthly_Check2SpectralGraphCount,data.Daily_Check2MacTrakGraphCount,data.Daily_Check2SpectralGraphCount);
          })        
       })
      
       it('Verify the System graph data Daily Both',function()
       {
          var TEST_DATA = XL.read_from_excel('SystemGraph','./e2e/e2e/util/testData/XperTrakTestData.xlsx')
          TEST_DATA.forEach(function(data)
            {
            EnterpriseSystemChartObject.clickSystemDailyButton();
            EnterpriseSystemChartObject.verifySysMactrakDropdown("both");
            EnterpriseSystemChartObject.sysVerifyCheck1SystemHighChartItemdataforBoth("daily","both",data.Monthly_Check1BothGraphCount,data.Daily_Check1BothGraphCount);
            EnterpriseSystemChartObject.sysVerifyCheck2SystemHighChartItemdataforBoth("daily","both",data.Monthly_Check2BothGraphCount,data.Daily_Check2BothGraphCount);
            })               
       })      

     it('Verify the Uncheck button functionality of the Systems graph',function()
        {
          var TEST_DATA = XL.read_from_excel('SystemGraph','./e2e/e2e/util/testData/XperTrakTestData.xlsx')
          TEST_DATA.forEach(function(data)
            {  
              EnterpriseSystemChartObject.uncheckSystemCheck1(data.checkboxShowAll,data.checkboxItem1,data.checkboxItem2);
              EnterpriseSystemChartObject.verifygraphdataDisplayedforCheck2(data.checkboxItem2);
              EnterpriseSystemChartObject.uncheckSystemCheck2(data.checkboxShowAll,data.checkboxItem1,data.checkboxItem2);
              EnterpriseSystemChartObject.verifygraphdataDisplayedforCheck1(data.checkboxItem1);
              EnterpriseSystemChartObject.uncheckandCheckSystemShowAll(data.checkboxShowAll,data.checkboxItem1,data.checkboxItem2);
              EnterpriseSystemChartObject.verifyUnCheckSystemShowAll(data.checkboxShowAll,data.checkboxItem1,data.checkboxItem2);
            })      
        })

      it('Verify click on System graph Menu button functionlity', function()
        {
          EnterpriseSystemChartObject.verifyclickSystemMenuButton();
        })
      
      it('Verify System graph Zoom functionality', function()
        {
          EnterpriseSystemChartObject.verifyRegionZoomButton();
        })
      
  })        