var loginPage = require('../../../pages/loginPO/loginScreen.po');
var HeaderVerificationObject = require('../../../pages/commonMethodsPO/headerVerification.po.js');
var common = require('../commonMethods/startUpSyncMethod');
var sync = require('../../../util/testData/constantTime');
const { browser } = require('protractor');

describe('Xpertrak EnterpriseSearch & Performance Application ', function()
{
  
       common.startUp();
      /* it('Login in to application with proper usename and credentials',function()
       {             
           loginPage.get("http://173.165.99.67/pathtrak/login/view.html#/login");
           sync.wait(5000);            
           loginPage.enterUserName("admin");
           loginPage.enterpassWord("admin");
           loginPage.clickSignin();
           sync.wait(15000);
           loginPage.get("http://173.165.99.67/pathtrak/enterprise/index.html#/entsearch");
           sync.wait(5000);
         
       })*/
       
       /*it('Verify open region search page',function()
       {  
           HeaderVerificationObject.OpenRegionalSearchPageVerification();

       })*/

      it('Verify viavi image',function()
       {  
           HeaderVerificationObject.viaviImageVerification();

       })

      it('Verify xpertrak content',function()
       {  
           HeaderVerificationObject.xperttrakContentVerification();

       })
        
       it('Verify toggle header',function()
       {  
           HeaderVerificationObject.toggleHeaderVerification();

       })

       it('Verify xpertrak theme',function()
       {  
           HeaderVerificationObject.xpertrackThemeVerification();

       })
       


 })     