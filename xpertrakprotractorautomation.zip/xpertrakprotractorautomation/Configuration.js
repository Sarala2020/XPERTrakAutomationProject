exports.config = {
    framework: 'jasmine2',
    //seleniumAddress: 'http://localhost:4444/wd/hub',

  suites: {
      Regression: ['./e2e/e2e/tests/regression/loginScreen/loginPage.spec.js',
      './e2e/e2e/tests/regression/enterpriseSearch/enterpriseSearchPage.spec.js',
      './e2e/e2e/tests/regression/commonMethods/headerVerification.spec.js',    
      './e2e/e2e/tests/regression/enterprisePerformance/regionalChartPage.spec.js',     
     './e2e/e2e/tests/regression/enterprisePerformance/systemChartPage.spec.js',
     './e2e/e2e/tests/regression/commonMethods/headerVerification.spec.js']                             
    },

    //Smoke: ['./e2e/e2e/tests/regression/loginScreen/loginPage.spec.js',
      //'./e2e/e2e/tests/regression/enterprisePerformance/systemChartPage.spec.js'],*/    
     //specs: ['./e2e/e2e/tests/regression/enterprisePerformance/systemChartPage.spec.js'],

    directConnect: true,
    capabilities: {
      'browserName': 'chrome'
    },
    plugins: [{
      package: 'protractor-screenshoter-plugin',
      screenshotPath: './REPORTS/e2e',
      screenshotOnExpect: 'failure+success',
      screenshotOnSpec: 'none',
      withLogs: true,
      writeReportFreq: 'asap',
      imageToAscii: 'none',
      clearFoldersBeforeTest: true
    }],

    onPrepare: function() {
        browser.driver.manage().window().maximize();
        global.globalData = require('../xpertrakprotractorautomation/e2e/e2e/util/testData/constantData');
      
        // returning the promise makes protractor wait for the reporter config before executing tests
        return global.browser.getProcessedConfig().then(function(config) {
            //it is ok to be empty
        });      
      },
}
//"test": "./node_modules/.bin/protractor Configuration.js ---suites Regression"


    

   
 
      